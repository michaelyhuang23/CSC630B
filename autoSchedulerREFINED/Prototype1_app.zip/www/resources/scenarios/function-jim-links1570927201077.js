(function(window, undefined) {

  var jimLinks = {
    "b42f3e59-3874-4c6a-b821-94fbc0d4a036" : {
      "Image_1" : [
        "2bdc348e-c41e-4cf1-8673-97f98736623f"
      ],
      "Row_cell_4" : [
        "2bdc348e-c41e-4cf1-8673-97f98736623f"
      ],
      "Input_1" : [
        "2bdc348e-c41e-4cf1-8673-97f98736623f"
      ],
      "Image_4" : [
        "2bdc348e-c41e-4cf1-8673-97f98736623f"
      ]
    },
    "61146ad3-390c-4c1c-a042-344ca279b26a" : {
    },
    "2bdc348e-c41e-4cf1-8673-97f98736623f" : {
      "Text_20" : [
        "b42f3e59-3874-4c6a-b821-94fbc0d4a036"
      ],
      "Image_43" : [
        "b42f3e59-3874-4c6a-b821-94fbc0d4a036"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);