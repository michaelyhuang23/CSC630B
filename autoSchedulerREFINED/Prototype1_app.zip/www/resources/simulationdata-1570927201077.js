function initData() {
  jimData.variables["rowselected"] = "";
  jimData.variables["name"] = "Justinmind\'s example";
  jimData.datamasters["Master"] = [
    {
      "id": 1,
      "datamaster": "Master",
      "userdata": {
        "Text": "Natasha Romanoff",
        "Image": "./images/bcf7e9e5-541d-4c02-9751-b03cc09b0070.png",
        "City": "New Jersey, New York"
      }
    },
    {
      "id": 2,
      "datamaster": "Master",
      "userdata": {
        "Text": "Betsy Braddock",
        "Image": "./images/08e82d6b-c74f-44a1-a5c4-9b9f8403d3df.png",
        "City": "Houston, Texas"
      }
    },
    {
      "id": 3,
      "datamaster": "Master",
      "userdata": {
        "Text": "Peter Quill",
        "Image": "./images/93680318-cc42-44fb-b0ff-099f22ab3cb4.png",
        "City": "Los Angeles, California"
      }
    },
    {
      "id": 4,
      "datamaster": "Master",
      "userdata": {
        "Text": "Wedge Antilles",
        "Image": "./images/6256483a-3372-4c63-8694-4f92ade5b397.png",
        "City": "San Francisco, California"
      }
    },
    {
      "id": 5,
      "datamaster": "Master",
      "userdata": {
        "Text": "Alyssa Ashcroft",
        "Image": "./images/0b982249-d7bf-448f-82b4-3f27ded7f38c.png",
        "City": "Cupertino, California"
      }
    },
    {
      "id": 6,
      "datamaster": "Master",
      "userdata": {
        "Text": "William Adama",
        "Image": "./images/48a3fac0-ed1b-42d5-9c1a-7538366995bd.png",
        "City": "San Francisco, California"
      }
    }
  ];

  jimData.isInitialized = true;
}