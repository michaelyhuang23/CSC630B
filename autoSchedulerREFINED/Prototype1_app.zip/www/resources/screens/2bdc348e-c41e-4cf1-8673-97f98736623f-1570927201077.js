jQuery("#simulation")
  .on("click", ".s-2bdc348e-c41e-4cf1-8673-97f98736623f .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Text_20")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/b42f3e59-3874-4c6a-b821-94fbc0d4a036",
                    "transition": {
                      "type": "slideright",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_41")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_41 > svg": {
                      "attributes": {
                        "overlay": "#007AFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29 span": {
                      "attributes": {
                        "color": "#007AFF",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_43 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_29 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_42 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_30 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_42")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_42 > svg": {
                      "attributes": {
                        "overlay": "#007AFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30 span": {
                      "attributes": {
                        "color": "#007AFF",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_43 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_29 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_41 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_30 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_43")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_43 > svg": {
                      "attributes": {
                        "overlay": "#007AFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31 span": {
                      "attributes": {
                        "color": "#007AFF",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_29 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_41 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_42 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_30 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/b42f3e59-3874-4c6a-b821-94fbc0d4a036",
                    "transition": {
                      "type": "slideright",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_29")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_29 > svg": {
                      "attributes": {
                        "overlay": "#007AFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32 span": {
                      "attributes": {
                        "color": "#007AFF",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_43 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_41 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_42 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_30 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_30")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_30 > svg": {
                      "attributes": {
                        "overlay": "#007AFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_33 span": {
                      "attributes": {
                        "color": "#007AFF",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_43 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_29 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_41 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Image_42 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_32 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_31 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_29 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30": {
                      "attributes": {
                        "font-size": "8.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#s-2bdc348e-c41e-4cf1-8673-97f98736623f #s-Text_30 span": {
                      "attributes": {
                        "color": "#8A8A8F",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "8.0pt"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("pageload", ".s-2bdc348e-c41e-4cf1-8673-97f98736623f .pageload", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Text_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_5" ],
                    "value": {
                      "action": "jimSubstring",
                      "parameter": [ {
                        "action": "jimSystemTime"
                      },"0","5" ]
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });